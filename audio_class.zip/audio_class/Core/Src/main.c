/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi2_tx;

/* USER CODE BEGIN PV */
 int16_t audioBufferStereo[128] =  {
	      0,     0,
	   1606,  1606,
	   3196,  3196,
	   4756,  4756,
	   6270,  6270,
	   7723,  7723,
	   9102,  9102,
	  10394, 10394,
	  11585, 11585,
	  12665, 12665,
	  13623, 13623,
	  14449, 14449,
	  15137, 15137,
	  15679, 15679,
	  16069, 16069,
	  16305, 16305,
	  16384, 16384,
	  16305, 16305,
	  16069, 16069,
	  15679, 15679,
	  15137, 15137,
	  14449, 14449,
	  13623, 13623,
	  12665, 12665,
	  11585, 11585,
	  10394, 10394,
	   9102,  9102,
	   7723,  7723,
	   6270,  6270,
	   4756,  4756,
	   3196,  3196,
	   1606,  1606,
	      0,     0,
	  -1606, -1606,
	  -3196, -3196,
	  -4756, -4756,
	  -6270, -6270,
	  -7723, -7723,
	  -9102, -9102,
	 -10394,-10394,
	 -11585,-11585,
	 -12665,-12665,
	 -13623,-13623,
	 -14449,-14449,
	 -15137,-15137,
	 -15679,-15679,
	 -16069,-16069,
	 -16305,-16305,
	 -16384,-16384,
	 -16305,-16305,
	 -16069,-16069,
	 -15679,-15679,
	 -15137,-15137,
	 -14449,-14449,
	 -13623,-13623,
	 -12665,-12665,
	 -11585,-11585,
	 -10394,-10394,
	  -9102, -9102,
	  -7723, -7723,
	  -6270, -6270,
	  -4756, -4756,
	  -3196, -3196,
	  -1606, -1606
	};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_I2S2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

/* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_I2S2_Init();
  /* USER CODE BEGIN 2 */
  HAL_Delay(200);
  //turn on
  GPIOB->BSRR = GPIO_BSRR_BS11;

  HAL_I2S_Transmit_DMA(
      &hi2s2,
      (uint16_t *)audioBufferStereo,
      128
  );

  HAL_Delay(3000);
  HAL_I2S_DMAStop(&hi2s2);
  //turn off
    GPIOB->BSRR = GPIO_BSRR_BR11;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_4);
  while(LL_FLASH_GetLatency()!= LL_FLASH_LATENCY_4)
  {
  }
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE1);
  LL_RCC_HSE_Enable();

   /* Wait till HSE is ready */
  while(LL_RCC_HSE_IsReady() != 1)
  {

  }
  LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_5, 180, LL_RCC_PLLP_DIV_2);
  LL_RCC_PLL_ConfigDomain_48M(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_5, 180, LL_RCC_PLLQ_DIV_6);
  LL_RCC_PLL_Enable();

   /* Wait till PLL is ready */
  while(LL_RCC_PLL_IsReady() != 1)
  {

  }
  while (LL_PWR_IsActiveFlag_VOS() == 0)
  {
  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_4);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_2);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);

   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)
  {

  }
  LL_SetSystemCoreClock(144000000);

   /* Update the time base */
  if (HAL_InitTick (TICK_INT_PRIORITY) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  LL_RCC_PLLI2S_ConfigDomain_I2S(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLI2SM_DIV_5, 240, LL_RCC_PLLI2SR_DIV_3);
  LL_RCC_PLLI2S_Enable();

   /* Wait till PLL is ready */
  while(LL_RCC_PLLI2S_IsReady() != 1)
  {

  }
}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_8K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  TIM_InitStruct.Prescaler = 0;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 4294967295;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM2, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM2);
  LL_TIM_SetClockSource(TIM2, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM2, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM2);
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOH);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_11|LL_GPIO_PIN_12|LL_GPIO_PIN_13|LL_GPIO_PIN_14);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_11|LL_GPIO_PIN_12|LL_GPIO_PIN_13;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_14;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
 //old DMA initialization:
  void dma_initialization_old(void){
	  // DMA ON sequence (AN4031, pages14, p31)
	    // A)configure DMA stream
	    // B)Enable DMA stream in SxCR
	    // C)Enable the peripheral is used.
	    // 1)disable DMA
	     DMA1_Stream1->CR &= ~DMA_SxCR_EN;
	     while(DMA1_Stream1->CR & DMA_SxCR_EN) {
	  	   //waiting until DMA busy and terminated work
	     }
	       // 2)Set peripherial address:
	     DMA1_Stream1->PAR = (uint32_t) &SPI1->DR;
	       // 3)Set memory address:
	     DMA1_Stream1->M0AR =  (uint32_t)audioBufferStereo;
	       // 4)Configure the total number of data items to be transferred
	     DMA1_Stream1->NDTR = 0x0040; //64bytes
	       // 5)Select the DMA channel (request) using CHSEL[2:0] in the DMA_SxCR register
	       // Channel 3
	     DMA1_Stream1->CR &= ~DMA_SxCR_CHSEL;
	     DMA1_Stream1->CR |= (3 << DMA_SxCR_CHSEL_Pos);  // Channel 3

	       // 6)If the peripheral is intended to be the flow controller  , set    the PFCTRL bit in the DMA_SxCR register.
	       // 7)Configure the stream priority using the PL[1:0] bits in the DMA_SxCR register.
	     DMA1_Stream1->CR |= DMA_SxCR_PL_0; //medium priority level
	       // 8). Configure the FIFO usage (enable or disable, threshold in transmission and reception).
	       /* 9. Configure the data transfer direction, peripheral and memory incremented/fixed mode,
	  		single or burst transactions, peripheral and memory data widths, Circular mode,
	  		Double-buffer mode and interrupts after half and/or full transfer, and/or errors in the
	  		DMA_SxCR register.*/
	      //9.1) data transfer direction:
	     DMA1_Stream1->CR |= DMA_SxCR_DIR_0; //mem to periph
	      //9.2) Memory increment
	     DMA1_Stream1->CR |= DMA_SxCR_MINC;
	      //9.3) Peripherial and memory data width
	     DMA1_Stream1->CR |= 0; // 1byte - memory. DMA_SxCR_MSIZE_0, DMA_SxCR_MSIZE_1
	     DMA1_Stream1->CR |= 0; //1byte - peripherial.  DMA_SxCR_PSIZE_0, DMA_SxCR_PSIZE_0
	      //9.4)Normal/circular mode
	     DMA1_Stream1->CR |= DMA_SxCR_CIRC;
	     // FIFO direct mode
	     DMA1_Stream1->FCR = 0x00;
	      //10)Enable DMA stream
	     DMA1_Stream1->CR |= DMA_SxCR_EN;
	     while(!(DMA1_Stream1->CR & DMA_SxCR_EN)) {
	   	   //waiting until DMA busy and terminated work
	      }
	     //****enable periphherial
	     SPI1->CR1 |= SPI_CR1_SPE;
	     SPI1->CR2 |= SPI_CR2_TXDMAEN;
	     //**********TIM*******
	     TIM2->ARR = 0x6fff;
	     TIM2->CR1 = TIM_CR1_CEN;


  }
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
