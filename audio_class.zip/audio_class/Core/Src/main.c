/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
 uint8_t audioBufferMono[128] =  {
		 0x78,0x7D,0x82,0x87,0x8C,0x90,0x95,0x9A,0x9E,0xA3,
		 0xA7,0xAB,0xB0,0xB4,0xB7,0xBB,0xBF,0xC2,0xC5,0xC8,
		 0xCB,0xCE,0xD0,0xD2,0xD4,0xD6,0xD8,0xD9,0xDA,0xDB,
		 0xDC,0xDC,0xDC,0xDC,0xDC,0xDB,0xDA,0xD9,0xD8,0xD6,
		 0xD4,0xD2,0xD0,0xCE,0xCB,0xC8,0xC5,0xC2,0xBF,0xBB,
		 0xB7,0xB4,0xB0,0xAB,0xA7,0xA3,0x9E,0x9A,0x95,0x90,
		 0x8C,0x87,0x82,0x7D,0x78,0x73,0x6E,0x69,0x64,0x60,
		 0x5B,0x56,0x52,0x4D,0x49,0x45,0x40,0x3C,0x39,0x35,
		 0x31,0x2E,0x2B,0x28,0x25,0x22,0x20,0x1E,0x1C,0x1A,
		 0x18,0x17,0x16,0x15,0x14,0x14,0x14,0x14,0x14,0x15,
		 0x16,0x17,0x18,0x1A,0x1C,0x1E,0x20,0x22,0x25,0x28,
		 0x2B,0x2E,0x31,0x35,0x39,0x3C,0x40,0x45,0x49,0x4D,
		 0x52,0x56,0x5B,0x60,0x64,0x69,0x6E,0x73
	};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_DAC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void incomingOutCallback(uint8_t* pbuf, uint32_t size) {

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_DAC_Init();
  /* USER CODE BEGIN 2 */
  // DMA ON sequence (AN4031, pages14, p31)
    // A)configure DMA stream 5,  Channel 7
    // B)Enable DMA stream in SxCR
    // C)Enable the peripheral is used.
    // 1)disable DMA
     DMA1_Stream5->CR &= ~DMA_SxCR_EN;
     while(DMA1_Stream5->CR & DMA_SxCR_EN) {
  	   //waiting until DMA busy and terminated work
     }
       // 2)Set peripherial address:
     DMA1_Stream5->PAR = (uint32_t) &DAC->DHR8R1;  /*!< DAC channel1 8-bit right aligned data holding register,  Address offset: 0x10 */
       // 3)Set memory address:
     DMA1_Stream5->M0AR =  (uint32_t)audioBufferMono;
       // 4)Configure the total number of data items to be transferred
     DMA1_Stream5->NDTR = 0x0080; //128bytes
       // 5)Select the DMA channel (request) using CHSEL[2:0] in the DMA_SxCR register
       // Channel 3
     DMA1_Stream5->CR &= ~DMA_SxCR_CHSEL;
     DMA1_Stream5->CR |= ( DMA_SxCR_CHSEL_0 | DMA_SxCR_CHSEL_1 | DMA_SxCR_CHSEL_2 );  // Channel 7

       // 6)If the peripheral is intended to be the flow controller  , set    the PFCTRL bit in the DMA_SxCR register.
       // 7)Configure the stream priority using the PL[1:0] bits in the DMA_SxCR register.
     DMA1_Stream5->CR |= DMA_SxCR_PL_0; //medium priority level
       // 8). Configure the FIFO usage (enable or disable, threshold in transmission and reception).
       /* 9. Configure the data transfer direction, peripheral and memory incremented/fixed mode,
  		single or burst transactions, peripheral and memory data widths, Circular mode,
  		Double-buffer mode and interrupts after half and/or full transfer, and/or errors in the
  		DMA_SxCR register.*/
      //9.1) data transfer direction:
     DMA1_Stream5->CR |= DMA_SxCR_DIR_0; //mem to periph
      //9.2) Memory increment
     DMA1_Stream5->CR |= DMA_SxCR_MINC;
      //9.3) Peripherial and memory data width
     DMA1_Stream5->CR &= ~(DMA_SxCR_MSIZE|DMA_SxCR_PSIZE);
     DMA1_Stream5->CR |= 0; // 1byte - memory. DMA_SxCR_MSIZE_0, DMA_SxCR_MSIZE_1
     DMA1_Stream5->CR |= 0; //1byte - peripherial.  DMA_SxCR_PSIZE_0, DMA_SxCR_PSIZE_0
      //9.4)Normal/circular mode
     DMA1_Stream5->CR |= DMA_SxCR_CIRC;
     // FIFO direct mode
     DMA1_Stream5->FCR = 0x00;
      //10)Enable DMA stream
     DMA1_Stream5->CR |= DMA_SxCR_EN;
     while(!(DMA1_Stream5->CR & DMA_SxCR_EN)) {
   	   //waiting until DMA busy and terminated work
      }
     //****enable periphherial
     // Timer 2 TRGO event |  DAC channel1 trigger enable |DAC channel1 DMA enable
      DAC->CR |= (DAC_CR_TSEL1_2| DAC_CR_TEN1|DAC_CR_DMAEN1);
      //enable DAC Channel 1
      DAC->CR |= DAC_CR_EN1;

     //**********TIM*******
     TIM2->ARR = 0x1990;
     TIM2->CR2 &= ~TIM_CR2_MMS;
     TIM2->CR2 |=  TIM_CR2_MMS_1;   //TRGO enable: on update event
     TIM2->CR1 = TIM_CR1_CEN;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_4);
  while(LL_FLASH_GetLatency()!= LL_FLASH_LATENCY_4)
  {
  }
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE1);
  LL_RCC_HSE_Enable();

   /* Wait till HSE is ready */
  while(LL_RCC_HSE_IsReady() != 1)
  {

  }
  LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_5, 180, LL_RCC_PLLP_DIV_2);
  LL_RCC_PLL_ConfigDomain_48M(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_5, 180, LL_RCC_PLLQ_DIV_6);
  LL_RCC_PLL_Enable();

   /* Wait till PLL is ready */
  while(LL_RCC_PLL_IsReady() != 1)
  {

  }
  while (LL_PWR_IsActiveFlag_VOS() == 0)
  {
  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_4);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_2);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);

   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)
  {

  }
  LL_SetSystemCoreClock(144000000);

   /* Update the time base */
  if (HAL_InitTick (TICK_INT_PRIORITY) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  LL_DAC_InitTypeDef DAC_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_DAC1);

  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  /**DAC GPIO Configuration
  PA4   ------> DAC_OUT1
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_4;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* DAC DMA Init */

  /* DAC1 Init */
  LL_DMA_SetChannelSelection(DMA1, LL_DMA_STREAM_5, LL_DMA_CHANNEL_7);

  LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_STREAM_5, LL_DMA_DIRECTION_MEMORY_TO_PERIPH);

  LL_DMA_SetStreamPriorityLevel(DMA1, LL_DMA_STREAM_5, LL_DMA_PRIORITY_LOW);

  LL_DMA_SetMode(DMA1, LL_DMA_STREAM_5, LL_DMA_MODE_CIRCULAR);

  LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_STREAM_5, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_STREAM_5, LL_DMA_MEMORY_INCREMENT);

  LL_DMA_SetPeriphSize(DMA1, LL_DMA_STREAM_5, LL_DMA_PDATAALIGN_HALFWORD);

  LL_DMA_SetMemorySize(DMA1, LL_DMA_STREAM_5, LL_DMA_MDATAALIGN_HALFWORD);

  LL_DMA_DisableFifoMode(DMA1, LL_DMA_STREAM_5);

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC channel OUT1 config
  */
  DAC_InitStruct.TriggerSource = LL_DAC_TRIG_EXT_TIM2_TRGO;
  DAC_InitStruct.WaveAutoGeneration = LL_DAC_WAVE_AUTO_GENERATION_NONE;
  DAC_InitStruct.OutputBuffer = LL_DAC_OUTPUT_BUFFER_ENABLE;
  LL_DAC_Init(DAC, LL_DAC_CHANNEL_1, &DAC_InitStruct);
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  TIM_InitStruct.Prescaler = 0;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 4294967295;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM2, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM2);
  LL_TIM_SetClockSource(TIM2, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM2, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM2);
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* Init with LL driver */
  /* DMA controller clock enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1);

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  NVIC_SetPriority(DMA1_Stream5_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOH);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_11|LL_GPIO_PIN_12|LL_GPIO_PIN_13|LL_GPIO_PIN_14);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_11|LL_GPIO_PIN_12|LL_GPIO_PIN_13;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_14;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
 //old DMA initialization:
  void dma_initialization_old(void){
	  // DMA ON sequence (AN4031, pages14, p31)
	    // A)configure DMA stream
	    // B)Enable DMA stream in SxCR
	    // C)Enable the peripheral is used.
	    // 1)disable DMA
	     DMA1_Stream1->CR &= ~DMA_SxCR_EN;
	     while(DMA1_Stream1->CR & DMA_SxCR_EN) {
	  	   //waiting until DMA busy and terminated work
	     }
	       // 2)Set peripherial address:
	     DMA1_Stream1->PAR = (uint32_t) &SPI1->DR;
	       // 3)Set memory address:
	     DMA1_Stream1->M0AR =  (uint32_t)audioBufferMono;
	       // 4)Configure the total number of data items to be transferred
	     DMA1_Stream1->NDTR = 0x0040; //64bytes
	       // 5)Select the DMA channel (request) using CHSEL[2:0] in the DMA_SxCR register
	       // Channel 3
	     DMA1_Stream1->CR &= ~DMA_SxCR_CHSEL;
	     DMA1_Stream1->CR |= (3 << DMA_SxCR_CHSEL_Pos);  // Channel 3

	       // 6)If the peripheral is intended to be the flow controller  , set    the PFCTRL bit in the DMA_SxCR register.
	       // 7)Configure the stream priority using the PL[1:0] bits in the DMA_SxCR register.
	     DMA1_Stream1->CR |= DMA_SxCR_PL_0; //medium priority level
	       // 8). Configure the FIFO usage (enable or disable, threshold in transmission and reception).
	       /* 9. Configure the data transfer direction, peripheral and memory incremented/fixed mode,
	  		single or burst transactions, peripheral and memory data widths, Circular mode,
	  		Double-buffer mode and interrupts after half and/or full transfer, and/or errors in the
	  		DMA_SxCR register.*/
	      //9.1) data transfer direction:
	     DMA1_Stream1->CR |= DMA_SxCR_DIR_0; //mem to periph
	      //9.2) Memory increment
	     DMA1_Stream1->CR |= DMA_SxCR_MINC;
	      //9.3) Peripherial and memory data width
	     DMA1_Stream1->CR |= 0; // 1byte - memory. DMA_SxCR_MSIZE_0, DMA_SxCR_MSIZE_1
	     DMA1_Stream1->CR |= 0; //1byte - peripherial.  DMA_SxCR_PSIZE_0, DMA_SxCR_PSIZE_0
	      //9.4)Normal/circular mode
	     DMA1_Stream1->CR |= DMA_SxCR_CIRC;
	     // FIFO direct mode
	     DMA1_Stream1->FCR = 0x00;
	      //10)Enable DMA stream
	     DMA1_Stream1->CR |= DMA_SxCR_EN;
	     while(!(DMA1_Stream1->CR & DMA_SxCR_EN)) {
	   	   //waiting until DMA busy and terminated work
	      }
	     //****enable periphherial
	     SPI1->CR1 |= SPI_CR1_SPE;
	     SPI1->CR2 |= SPI_CR2_TXDMAEN;
	     //**********TIM*******
	     TIM2->ARR = 0x6fff;
	     TIM2->CR1 = TIM_CR1_CEN;


  }
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
